# TriviaGame
Who Wants to be a Programmer?? - GUI Application with PyQt5
<br>
This is a trivia game testing ones' level of computer science knowledge.
<br>
<br>
![Trivia Game with PyQt5](https://user-images.githubusercontent.com/32107652/116930221-54fb2280-ac14-11eb-8b10-2215c5401a06.jpg)
<br>
<br>
<b>Trivia Questions Database:</b>
<br>
https://opentdb.com/
<br>
<br>
<b>Trivia - Starter Files/</b>
<br>
contain all the files required to follow the step by step tutorial on Youtube.
<br>
<b>Python GUI App with PyQt5 - PART 1:</b>
<br>
https://youtu.be/9iZLDnW_vwU
<br>
<br>
<b>Trivia - Interface Only/</b>
<br>
contains the files of the first 2 frames only.
<br>
also, excluding all the functionality of the app - only focusing on design and switching frames.
<br>
This is the finished code of the <b>Part 1</b> tutorial on YouTube.
<br>
<br>
<b>Part 2 - Trivia - Starter Files/</b>
<br>
contains all the required files to complete the second part of the tutorial on Youtube:
<br>
<b>Python GUI App with PyQt5 - PART 2:</b>
<br>
https://youtu.be/r2ZN0mTDnPc
<br>
<br>
<b>Trivia - Complete App/</b>
<br>
contains the files of the complete application.
<br>
This is the finished code of the <b>Part 2</b> tutorial on YouTube.
<br>
<br>
<b>data base:</b> Open Trivia (https://opentdb.com/)
<br>
<b>dependencies:</b> Pandas, PyQt5
<br>
<b>author:</b> Mariya Sha
<br>
<br>
<b>Special Thank you</b> to m. B of Youtube for pointing out that triple quotes
<br>
are a much much better way of handiling multi-line strings than concatination!!!
<br>
my apologies for the brain freeze, I'll blame the blond ;)
<br>
<br>
<b>FOR MORE COOL PYTHON PROJECTS AND STEP BY STEP TUTORIALS:</b>
<br>
visit my Youtube channel:
<br>
https://www.youtube.com/c/pythonsimplified
<br>
visit my blog:
<br>
https://www.mariyasha.com
<br>
connect on Linkedin:
<br>
https://www.linkedin.com/in/mariyasha888/
<br>
find me on Instagram:
<br>
https://www.instagram.com/mariyasha888/
  
